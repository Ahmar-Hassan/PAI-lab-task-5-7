import pandas as pd


df = pd.read_csv('vehicles.csv')

def search_vehicle_by_reg(reg_number):
    result = df[df['reg_number'].str.lower() == reg_number.lower()]
    if not result.empty:
        return result.to_dict(orient='records')[0]
    else:
        return None

def add_vehicle(vehicle_data):
    global df
    df = pd.concat([df, pd.DataFrame([vehicle_data])], ignore_index=True)
    df.to_csv('vehicles.csv', index=False)

def update_vehicle(reg_number, field, new_value):
    global df
    idx = df[df['reg_number'] == reg_number].index
    if not idx.empty:
        df.at[idx[0], field] = new_value
        df.to_csv('vehicles.csv', index=False)
        return True
    return False

def delete_vehicle(reg_number):
    global df
    df = df[df['reg_number'] != reg_number]
    df.to_csv('vehicles.csv', index=False)


if __name__ == '__main__':
    reg = input("Enter vehicle registration number: ")
    info = search_vehicle_by_reg(reg)
    if info:
        print("Vehicle Info:")
        for key, val in info.items():
            print(f"{key.capitalize()}: {val}")
    else:
        print("Vehicle not found.")
